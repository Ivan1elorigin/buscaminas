
#include "header.h"
/*
int main() {
	int a = ;
	char dig='@';

	a += 48;

	printf("%c", (char)(a));
}

//Si a un entero de un d�gito le sumamos 48 y forzamos us conversi�n a char, podemos imprimir ese mismo n�mero representado en car�cteres.

*/

int main() {
	//Inicializamos la variables
	int tabla_cal[C][C], flag = 0;
	char tabla_ver[C][C];

	//Invocamos la semilla

	srand(time(NULL));

	

	do {
		int i = 0, j = 0, auxi = 0, auxj = 0, flagrand = 0, turnos=0;

		//Limpiamos el tablero
		limpiar_tablero(tabla_cal, tabla_ver);

		//Imprimimos el tablero
		imprime_tablero(tabla_ver);

		imprime_cal(tabla_cal);

		//colocamos las bombas en el tablero
		for (i = 0; i < M; i++) { //Colocamos M bombas a lo lago del tablero
			
			//Escogemos unas cordenadas que no est�n ocupadas. Las cordenadas aleatorias van de 0 a (C-1)
			
			do {
				auxi = (rand() % C);
				auxj = (rand() % C);

				if (tabla_cal[auxi][auxj] != 99) {
					flagrand = 1; //Si las coordenadas corresponden a una casilla vac�a, activamos la bandera y salimos del bucle.
				}
				//Importante preguntar.

				

			} while (flagrand == 0);
			flagrand = 0;


			tabla_cal[auxi][auxj] = 99; //El 99 es el valor equivalente a la bomba.
			

		}
		printf("\n");
		imprime_cal(tabla_cal);

		printf("\nMinas repartidas:\n");
		contabombas(tabla_cal);//Hacemos que en cada una de las casillas aparezca el n�mero de bombas de alrededor.

		printf("\nMinas analizadas:\n");

		imprime_cal(tabla_cal);

		//Hacer la funci�n tirar
		do {
			printf("\nAhora puedes tirar\n");
			if ((tirar(tabla_ver, tabla_cal, &turnos)) == 1) {
				printf("\nHa perdido\n");
				break;
			}
			printf("\nVa por el turno: %d\n", turnos);
			imprime_tablero(tabla_ver);
		} while ((casindesta(tabla_ver, tabla_cal, 0, 0))>M); //Quiero que est� en el bucle mientras el n�mero de casillas sin girar sea mayor que el n�mero de minas.
		printf("\nEl juego ha terminado.\n");
		ifichero(tabla_ver, tabla_cal, turnos);

		printf("\nDeseas finalizar?: 1 si 0 no:\n");
		scanf_s("%d", &flag);

		

	} while (flag==0);
	flag = 0;

	return 0;
}