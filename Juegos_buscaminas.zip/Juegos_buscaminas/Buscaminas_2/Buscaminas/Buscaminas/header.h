#pragma once
//Librer�as
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Constantes
#define C 5 //Casillas que tiene el costado del tablero
#define M 1 //N�mero de minas que hay en el tablero


//Prototipos
void limpiar_tablero(int[C][C], char[C][C]);

void imprime_tablero(char[C][C]);

void contabombas(int[C][C]);

int analizacasilla(int[C][C], int, int, int, int);

// Este prototipo es usado durante el desarrollo.

void imprime_cal(int[C][C]);


//void comprueba_casilla(int[C][C], int, int);


int tirar(char[C][C], int[C][C], int *); //Esta funci�n en caso de que se pise una bomba devuelve un 1, y en caso de que no devuelve un 0.

//Esta funci�n pretende que si una casilla est� vac�a, el resto casillas que hay alrededor se levanten (hasta un cierto l�mite).
int tiradauto(char tabla_ver[C][C], int tabla_cal[C][C], int i, int j, int gen);

//Esta func�on cuenta las casillas sin destapar.

int casindesta(char tabla_ver[C][C], int tabla_cal[C][C], int i, int j);