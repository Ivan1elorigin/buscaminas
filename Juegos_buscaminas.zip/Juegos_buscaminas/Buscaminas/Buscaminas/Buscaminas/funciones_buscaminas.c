#include "header.h"

void limpiar_tablero(int tabla_cal[C][C], char tabla_ver[C][C]) {
	int i = 0, j = 0;
	for (i = 0; i < C; i++) {
		for (j = 0; j < C; j++) {
			tabla_cal[i][j] = 0;
			tabla_ver[i][j] = '#';
		}
	}
}

void imprime_tablero(char tabla_ver[C][C]) {
	int i = 0, j = 0;
	for (i = 0; i < C; i++) {
		for (j = 0; j < C; j++) {
			printf("| %c |", tabla_ver[i][j]);
		}
		printf("\n");
	}
}
void contabombas(int tabla_cal[C][C]) { //Funci�n gpt-3
	int i = 0, j = 0, cont = 0, auxi = 0, auxj = 0;

	for (i = 0; i < C; i++) {
		for (j = 0; j < C; j++) {

			if (tabla_cal[i][j] != 99) { // Lo hacemos solo si la casilla que estamos haciendo no es una bomba.

				for (auxi = (i - 1); auxi <= (i + 1); auxi++) {
					for (auxj = (j - 1); auxj <= (j + 1); auxj++) {
						cont += analizacasilla(tabla_cal, auxi, auxj, i, j);//Le paso los par�metros que necesita (incluido la tabla)
					}
				}
				//Cuando terminamos de analizar las casillas de alrededor, asignamos el contador a la casilla y limpiamos el contador.
				tabla_cal[i][j] = cont;
				cont = 0;
			}

		}
	}
}
/*
* funci�n que he hecho yo
void contabombas(int tabla_cal[C][C]) {
	int i = 0, j = 0, cont = 0, auxi=0, auxj=0;

	for (i = 0; i < C; i++) {
		for (j = 0; j < C; j++) {


			if (tabla_cal[i][j] != 99) { // Lo hacemos solo si la casilla que estamos haciendo no es una bomba.

				for (auxi = (i - 1); auxi <= (i + 1); auxi++) {
					for (auxj = (j - 1); auxj <= (j + 1); auxj++) {
						cont += analizacasilla(tabla_cal, auxi, auxj, i, j);//Le paso los par�metros que necesita (incluido la tabla)
					}
				}
				//Cuando terminamos de analizar las casillas de alrededor, asignamos el contador a la casilla y limpiamos el contador.
				tabla_cal[i][j] = cont;
				cont = 0;
			}
			



		}




	}
}
*/
//Funci�n que he hecho yo.
/*
int analizacasilla(int tabla_cal[C][C], int auxi, int auxj, int i, int j) {
	if ((auxi != i) && (auxj != j)) { //No vale si la casilla es la propia misma. (la auxi=i, auxj=j)
		if ((0 <= auxi <= (C - 1)) && (0 <= auxj <= (C - 1))) {
			if (tabla_cal[auxi][auxj] == 99) { //Si en la casilla que estoy analizando me detectas una bomba, devu�lveme 1.
				return 1;
			}
		}
	}
	return 0; // Si no ha pasado nada, devuelveme 0
}
*/

int analizacasilla(int tabla_cal[C][C], int auxi, int auxj, int i, int j) { //Funci�n gpt-3
	if ((auxi == i) && (auxj == j)) { //La condici�n cambia a que las coordenadas son iguales
		return 0;
	}
	if ((0 <= auxi && auxi <= (C - 1)) && (0 <= auxj && auxj <= (C - 1))) { //La condici�n cambia a que las coordenadas est�n dentro de los l�mites del tablero
		if (tabla_cal[auxi][auxj] == 99) { //Si en la casilla que estoy analizando me detectas una bomba, devu�lveme 1.
			return 1;
		}
	}
	return 0; // Si no ha pasado nada, devuelveme 0
}

void imprime_cal(int tabla_cal[C][C]) {
	int i = 0, j=0;
	for (i = 0; i < C; i++) {
		for (j = 0; j < C; j++) {
			printf("| %d |", tabla_cal[i][j]);
		}
		printf("\n");
	}
}

int tirar(char tabla_ver[C][C], int tabla_cal[C][C], int *turnos) {
	int mode = 0, flag = 0, posi = 0, posj = 0, flag1 = 0;
	

	do {
		printf("\nPulse 0 para destapar una casilla o 1 para colocar una bandera en la casilla:\n");
		scanf_s("%d", &mode);
		if (mode == 0) { //Tirar
			flag = 1; //Activamos la flag.
			do {
				printf("\nSeleccione las coordenadas:\n"); //Verificamos coordenadas
				printf("\nCoordenada i:\n");
				scanf_s("%d", &posi);
				printf("\n\Coordenada j:\n");
				scanf_s("%d", &posj);
				if ((0 <= posi && posi <= (C - 1)) && (0 <= posj && posj <= (C - 1))) { //Si las coordenadas est�n dentro del tablero, me asigna 1 a flag 1. (Me activa la flag).
					if ((tabla_ver[posi][posj] == '#') || (tabla_ver[posi][posj] == 'B')) { // Se asegura que la casilla no haya sido destapada.
						flag1 = 1;
					}
				}
				else {
					flag = 0;
					printf("\nLas coordenadas que has introducido no se encuentran dentro del tablero o ya han sido destapadas. Por favor, introduce de nuevo los valores.\n");

				}
			} while (flag1 == 0);
			flag1 = 0;

			if (tabla_cal[posi][posj] == 99) {
				tabla_ver[posi][posj] = '@'; //Utilizamos el caracter @ para representar una bomba.
				return 1;
				//Me lo pone en el tablero y me explota la bomba
			}

			else {
				tabla_ver[posi][posj] = (char)(tabla_cal[posi][posj]+48); //Cogemos el valor num�rico, le sumamos 48 y le hacemos cast para pasarlo a car�cter.
				(*turnos)++; //Cada vez que se tira y no se pisa una bomba, el turno se incrementa, si al final de la partida no se ha pisado una bomba, se cumple la siguiente condici�n: Condici�n del final de do while
			}

			//Destapar casilla
		}
		else if (mode == 1) {
			do {
				printf("\nSeleccione las coordenadas:\n"); //Verificamos coordenadas
				printf("\nCoordenada i:\n");
				scanf_s("%d", &posi);
				printf("\n\Coordenada j:\n");
				scanf_s("%d", &posj);
				if ((0 <= posi && posi <= (C - 1)) && (0 <= posj && posj <= (C - 1))) { //Si las coordenadas est�n dentro del tablero, me asigna 1 a flag 1. (Me activa la flag).
					if ((tabla_ver[posi][posj] == '#') || (tabla_ver[posi][posj] == 'B')) { // Se asegura que la casilla no haya sido destapada.
						flag1 = 1;
					}
				}
				else {
					flag = 0;
					printf("\nLas coordenadas que has introducido no se encuentran dentro del tablero o ya han sido destapadas. Por favor, introduce de nuevo los valores.\n");

				}
			} while (flag1 == 0);
			flag1 = 0;
			flag = 1; //Activamos la flag.
			tabla_ver[posi][posj] = 'B';
			//Poner banderita
		}
		else {
			printf("\nHa introducido un valor de modo incorrecto. Por favor, introduzca un 0 o un 1.\n");
		}

	} while (flag == 0);
	flag = 0;

	return 0;
} //La funci�n est� terminada!!!

/*
void comprueba_casilla(int tabla_cal[C][C], int i, int j) {
	int cont = 0;
	if (tabla_cal[i][j] != 99) {
		if (((i - 1) < (C - 1) && (j) < (C - 1))) {

			//lo programamos para cada una de las casillas contiguas
			if ((tabla_cal[i - 1][j] == 99)) { //Tenemos que poner unas condiciones para que no se pueda leer fuera de la tabla
				cont++;
			}
			if ((tabla_cal[i - 1][j + 1] == 99)) {
				cont++;
			}
			if ((tabla_cal[i][j + 1] == 99)) {
				cont++;
			}
			if ((tabla_cal[i + 1][j + 1] == 99)) {
				cont++;
			}
			if ((tabla_cal[i + 1][j] == 99)) {
				cont++;
			}
			if ((tabla_cal[i + 1][j - 1] == 99) && ((i + 1) < (C - 1) && (j - 1) < (C - 1))) {
				cont++;
			}
			if ((tabla_cal[i][j - 1] == 99) && ((i) < (C - 1) && (j - 1) < (C - 1))) {
				cont++;
			}
			if ((tabla_cal[i - 1][j - 1] == 99) && ((i - 1) < (C - 1) && (j - 1) < (C - 1))) {
				cont++;
			}
		}
	}
}
*/

/*


for (i = 0; i < C; i++) {
		for (j = 0; j < C; j++) {

			if (tabla_cal[i][j] != 99) {
				//Con esto nos aseguramos que no lea fuera de la tabla
				if ((0<=(i - 1) <= (C - 1)) && (0<=(j) <= (C - 1))){
					if ((tabla_cal[i - 1][j] == 99)) { //Tenemos que poner unas condiciones para que no se pueda leer fuera de la tabla
						cont++;
					}
				}


				if ((0<=(i - 1) <= (C - 1)) && (0<=(j + 1) <= (C - 1))) {
					if ((tabla_cal[i - 1][j + 1] == 99)) {
						cont++;
					}
				}



				if ((0<=(i) <= (C - 1)) && (0<=(j + 1) <= (C - 1))) {
					if ((tabla_cal[i][j + 1] == 99)) {
						cont++;
					}
				}

				if ((0<=(i + 1) <= (C - 1)) && (0<=(j + 1) <= (C - 1))) {
					if ((tabla_cal[i + 1][j + 1] == 99)) {
						cont++;
					}
				}



				if ((0<=(i + 1) <= (C - 1)) && (0<=(j) <= (C - 1))) {
					if ((tabla_cal[i + 1][j] == 99)) {
						cont++;
					}
				}



				if ((0<=(i + 1) <= (C - 1)) && (0<=(j - 1) <= (C - 1))) {

					if ((tabla_cal[i + 1][j - 1] == 99)) {
						cont++;
					}
				}

				if ((0<=(i) <= (C - 1)) && (0<=(j - 1) <= (C - 1))) {
					if ((tabla_cal[i][j - 1] == 99)) {
						cont++;
					}
				}

				if ((0<=(i - 1) <= (C - 1)) && (0<=(j - 1) <= (C - 1))) {
					if ((tabla_cal[i - 1][j - 1] == 99)) {
						cont++;
					}
				}

				//En cada casilla ponemos el n�mero de minas que hay alrededor.

				tabla_cal[i][j] = cont;
				 //Aqui no se reestablece el contador

			}

			//Limpiamos el contador aqu� (fuera del if != 99) porque creo que es lo que hace que la funci�n cuente mal las minas contiguas
			cont = 0; //Establecemos el contador a 0
		}
	}




*/